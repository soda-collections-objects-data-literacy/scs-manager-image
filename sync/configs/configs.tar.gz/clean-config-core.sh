#!/usr/bin/env bash
set -euo pipefail

dir="${1:-.}"

if [[ ! -d "$dir" ]]; then
  printf 'Directory %s does not exist.\n' "$dir" >&2
  exit 1
fi

for file in "$dir"/*.yml; do
  [[ -f "$file" ]] || continue

  python3 - <<'PYTHON' "$file"
import pathlib, sys, yaml

path = pathlib.Path(sys.argv[1])
text = path.read_text()
if not text.strip():
    sys.exit(0)

data = yaml.safe_load(text)

if not isinstance(data, dict):
    sys.exit(0)

removed = False
for key in ("_core", "uuid", "default_config_hash"):
    if key in data:
        data.pop(key)
        removed = True

if removed:
    path.write_text(yaml.safe_dump(data, sort_keys=False))
PYTHON
done
